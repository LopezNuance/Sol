from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from .schemas import validate_json_schema
from .engine import semantic_diagnostics, root_bound, infer_all_bounds
from .certificate import validate_certificate
from .diagnostics import Diagnostic, diag


def load_json(path: Path):
    return json.loads(path.read_text())


def validate_case_dir(path: Path) -> list[Diagnostic]:
    query_path = path / "query.json"
    cert_path = path / "certificate.json"
    bounds_path = path / "expected_bounds.json"
    diags: list[Diagnostic] = []
    if not query_path.exists():
        return [diag("QRY-SCHEMA-000", "missing_file", str(query_path), "query.json missing")]
    try:
        query = load_json(query_path)
    except Exception as e:
        return [diag("QRY-SCHEMA-000", "json_parse", str(query_path), str(e))]
    diags.extend(validate_json_schema(query, "qry_query.schema.json", "query"))
    if diags:
        return sorted(diags, key=lambda d: (d.rule_id, d.target, d.message))
    diags.extend(semantic_diagnostics(query))
    if not diags:
        if bounds_path.exists():
            try:
                expected_bounds = load_json(bounds_path)
                diags.extend(validate_json_schema(expected_bounds, "qry_bounds.schema.json", "expected_bounds"))
                if not diags:
                    actual = root_bound(query).to_json()
                    expected_root = expected_bounds.get("root_bound")
                    if actual != expected_root:
                        diags.append(diag("QRY-BOUND-001", "bound_mismatch", "expected_bounds.root_bound", "Expected root bound does not match inferred bound"))
            except Exception as e:
                diags.append(diag("QRY-BOUND-000", "bounds_error", str(bounds_path), str(e)))
        cert = None
        if cert_path.exists():
            try:
                cert = load_json(cert_path)
                diags.extend(validate_json_schema(cert, "qry_certificate.schema.json", "certificate"))
            except Exception as e:
                diags.append(diag("QRY-CERT-000", "certificate_error", str(cert_path), str(e)))
        if not any(d.rule_id.startswith("QRY-CERT") for d in diags):
            diags.extend(validate_certificate(query, cert))
    return sorted(diags, key=lambda d: (d.rule_id, d.target, d.message))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("case_dir")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    diags = validate_case_dir(Path(args.case_dir))
    if args.json:
        print(json.dumps([d.to_json() for d in diags], indent=2, sort_keys=True))
    else:
        if not diags:
            print("valid")
        for d in diags:
            print(f"{d.severity}\t{d.rule_id}\t{d.category}\t{d.target}\t{d.message}")
    return 1 if any(d.severity == "error" for d in diags) else 0

if __name__ == "__main__":
    raise SystemExit(main())
