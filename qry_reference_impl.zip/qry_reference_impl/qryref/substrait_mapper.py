from __future__ import annotations
from typing import Any
from .engine import semantic_diagnostics
from .diagnostics import diag, Diagnostic

SUPPORTED_OPS = {"read", "filter", "project", "limit", "sort", "distinct", "aggregate", "join", "union_all", "union_distinct", "rename"}


def validate_substrait_profile(query: dict[str, Any]) -> list[Diagnostic]:
    out = []
    for n in query.get("nodes", []):
        if n.get("op") not in SUPPORTED_OPS:
            out.append(diag("QRY-SUBSTRAIT-001", "substrait_unsupported_op", f"node:{n.get('id')}", f"Operation {n.get('op')!r} is outside QRY Substrait profile"))
    return out


def to_substrait_like(query: dict[str, Any]) -> dict[str, Any]:
    """Produce a human-readable Substrait-like JSON sketch.

    This is intentionally not a full protobuf serializer. The package profile in
    substrait/qry_substrait_profile.yaml defines the supported subset.
    """
    return {
        "version": {"minorNumber": 1, "producer": "qryref.v0.1"},
        "extensions": ["urn:qry:v0.1:bound-algebra"],
        "roots": [{"input": query.get("root"), "names": []}],
        "relations": [
            {"node_id": n.get("id"), "qry_op": n.get("op"), "detail": {k: v for k, v in n.items() if k not in {"id", "op"}}}
            for n in query.get("nodes", [])
        ]
    }
