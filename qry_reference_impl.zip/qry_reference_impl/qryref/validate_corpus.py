from __future__ import annotations
import argparse, json
from pathlib import Path
from .validate import validate_case_dir


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("corpus_dir")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    root = Path(args.corpus_dir)
    case_dirs = sorted((root / "cases").glob("QRY-*")) if (root / "cases").exists() else sorted(root.glob("QRY-*"))
    results = []
    ok = 0
    for c in case_dirs:
        manifest = json.loads((c / "manifest.json").read_text())
        expected = set(manifest.get("expected_diagnostics", []))
        diags = validate_case_dir(c)
        got = {d.rule_id for d in diags}
        passed = expected.issubset(got)
        if not expected and got:
            passed = False
        if passed: ok += 1
        results.append({
            "case_id": c.name,
            "passed": passed,
            "expected": sorted(expected),
            "got": sorted(got),
            "diagnostics": [d.to_json() for d in diags],
        })
    if args.json:
        print(json.dumps(results, indent=2, sort_keys=True))
    else:
        for r in results:
            status = "ok" if r["passed"] else "FAIL"
            print(f"{status}\t{r['case_id']}\texpected={','.join(r['expected']) or '-'}\tgot={','.join(r['got']) or '-'}")
        print(f"{ok}/{len(results)} cases satisfied expected diagnostics")
    return 0 if ok == len(results) else 1

if __name__ == "__main__":
    raise SystemExit(main())
