# QRY to Substrait Profile Notes

Substrait is a cross-language serialization format for relational algebra plans. QRY uses a deliberately small logical subset and adds bound-oriented annotations that are not standard Substrait semantics:

- source row bounds
- filter selectivity bounds
- join relationship hints
- proof-certificate rule identifiers

QRY's reference mapper (`qryref.substrait_mapper`) emits a Substrait-like JSON sketch rather than a protobuf plan. Full protobuf emission is out of scope for this reconstructed v0.1 package.

The profile follows Substrait's extension guidance: prefer standard logical relations where possible and use extension metadata for bound algebra only where needed.
