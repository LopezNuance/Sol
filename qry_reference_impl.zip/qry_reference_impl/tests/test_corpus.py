from pathlib import Path
import json
from qryref.validate import validate_case_dir

ROOT = Path(__file__).resolve().parents[1]

def test_corpus_expected_diagnostics():
    cases = sorted((ROOT / 'corpus' / 'cases').glob('QRY-*'))
    assert len(cases) == 69
    for case in cases:
        manifest = json.loads((case / 'manifest.json').read_text())
        expected = set(manifest.get('expected_diagnostics', []))
        got = {d.rule_id for d in validate_case_dir(case)}
        if expected:
            assert expected.issubset(got), (case.name, expected, got)
        else:
            assert not got, (case.name, got)
